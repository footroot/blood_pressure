export {default as BarController} from './controller.bar.js';
export {default as BubbleController} from './controller.bubble.js';
export {default as DoughnutController} from './controller.doughnut.js';
export {default as LineController} from './controller.line.js';
export {default as PolarAreaController} from './controller.polarArea.js';
export {default as PieController} from './controller.pie.js';
export {default as RadarController} from './controller.radar.js';
export {default as ScatterController} from './controller.scatter.js';
